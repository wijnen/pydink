void talk ()
{
	freeze (1);
	say_stop ("`%Cabbage, grapes, cake, fish and oil.", 1);
	say_stop ("In other words, a shopping list.", 1);
	unfreeze (1);
}
