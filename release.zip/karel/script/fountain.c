void talk ()
{
	freeze (1);
	say_stop ("A fountain in the entrance hall. Cool!", 1);
	unfreeze (1);
}
