void talk ()
{
	freeze (1);
	say_stop ("Some old meat, an old cake, and...", 1);
	say_stop ("a skull???", 1);
	unfreeze (1);
}
