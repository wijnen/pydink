void talk ()
{
	freeze (1);
	say_stop ("This seems to be sheet music.", 1);
	say_stop ("But it's written by hand.", 1);
	say_stop ("Oh, it's signed 'Machteld'.", 1);
	say_stop ("What a woman, so beautiful and a composer, too.", 1);
	unfreeze (1);
}
