void talk ()
{
	freeze (1);
	say_stop ("This seems to be fresh.", 1);
	say_stop ("Probably bought yesterday.", 1);
	unfreeze (1);
}
