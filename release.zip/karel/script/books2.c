void talk ()
{
	freeze (1);
	say_stop ("Just cooking books and printed music.", 1);
	unfreeze (1);
}
