void talk ()
{
	freeze (1);
	say_stop ("Oil, milk, water, wine!", 1);
	say_stop ("No, wait, it's vinegar.", 1);
	unfreeze (1);
}
