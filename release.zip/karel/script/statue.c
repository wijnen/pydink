void talk ()
{
	freeze (1);
	say_stop ("These are empty suits of armour. Neat!", 1);
	unfreeze (1);
}
