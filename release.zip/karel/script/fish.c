void talk ()
{
	freeze (1);
	say_stop ("This is extremely fresh!", 1);
	say_stop ("It's still alive!", 1);
	unfreeze (1);
}
