void talk ()
{
	freeze (1);
	say_stop ("It's a map. It looks like king Daniel's castle.", 1);
	say_stop ("Why would Eggeric have a map of that?", 1);
	unfreeze (1);
}
