void talk ()
{
	freeze (1);
	say_stop ("Some notes about a puzzle.", 1);
	say_stop ("They just seem random letters to me...", 1);
	unfreeze (1);
}
