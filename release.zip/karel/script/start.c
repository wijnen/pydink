void main ()
{
	make_start.main ();
}
