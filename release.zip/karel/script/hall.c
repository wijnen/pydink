extern int herb;
void main ()
{
	if (herb == 3)
	{
		herb = 4;
		save_game (-1);
	}
}
