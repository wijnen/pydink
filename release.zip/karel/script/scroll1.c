void talk ()
{
	freeze (1);
	say_stop ("It's a payment confirmation.", 1);
	say_stop ("He bought a bomb.", 1);
	say_stop ("Why does he need that, it's not war?", 1);
	unfreeze (1);
}
