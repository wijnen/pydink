void talk ()
{
	freeze (1);
	say_stop ("`%Liquid living fish illusion.", 1);
	say_stop ("Cool!", 1);
	unfreeze (1);
}
