void talk ()
{
	freeze (1);
	say_stop ("This wouldn't be a good dmod if there wasn't a secret passage here.", 1);
	say_stop ("Hmm... Perhaps this isn't a good dmod.", 1);
	say_stop ("That, or I'm a lousy searcher...", 1);
	unfreeze (1);
}
