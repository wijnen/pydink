void talk ()
{
	freeze (1);
	say_stop ("Something about king Daniel being a jerk.", 1);
	say_stop ("Ah, this is 'the Awful Truth', a forbidden newspaper.", 1);
	unfreeze (1);
}
