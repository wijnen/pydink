void talk ()
{
	freeze (1);
	say_stop ("These shelves are filled with puzzle books.", 1);
	unfreeze (1);
}
