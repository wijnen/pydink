void talk ()
{
	freeze (1);
	say_stop ("Some notes about writing an article.", 1);
	say_stop ("Not very interesting...", 1);
	unfreeze (1);
}
