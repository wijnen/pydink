void main ()
{
	say ("What?", 1);
}
