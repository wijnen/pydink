void main ()
{
	// The intro script must put Dink at his starting position.
	player_map = 400;
	sp_x (1, 320);
	sp_y (1, 200);
}
